import { ConnectView } from "../components/connect-view";

export default function ProfilePage() {
  return <ConnectView />;
}
