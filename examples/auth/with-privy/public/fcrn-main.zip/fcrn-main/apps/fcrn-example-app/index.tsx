import "expo-router/entry";
import "react-native-gesture-handler";
import "react-native-get-random-values";
import "./global";
