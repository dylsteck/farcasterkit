import { TextEncoder } from "text-encoding";
import { Buffer } from "buffer";

global.TextEncoder = TextEncoder;
global.Buffer = Buffer;
