import { FeedView } from "../components/feed-view";

export default function TabOneScreen() {
  return <FeedView />;
}
