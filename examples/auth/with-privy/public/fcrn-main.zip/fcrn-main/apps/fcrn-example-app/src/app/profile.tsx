import { ProfileView } from "../components/profile-view";

export default function ProfilePage() {
  return <ProfileView fid="191509" />;
}
