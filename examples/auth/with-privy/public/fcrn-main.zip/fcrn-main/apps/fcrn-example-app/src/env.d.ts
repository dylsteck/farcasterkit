declare module "@env" {
  export const NEYNAR_API_KEY: string;
  export const APP_FID: number;
  export const APP_MNEMONIC: string;
  export const HUB_URL: string;
}
